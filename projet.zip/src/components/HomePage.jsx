import React from 'react';
import './HomePage.css';

const HomePage = () => (
  <div className="home">
    <div className="intro">
      <h1>Hi, I'm seifallah mahfoudhi.</h1>
      <h2>I'm a computer programmer.</h2>
      <p>I'm a Tunisian develper who loves building digital products.</p>
    </div>
  </div>
);

export default HomePage;
